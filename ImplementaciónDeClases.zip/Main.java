// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Persona persona = new Persona("Juan", "Perez", "123456789", "Calle 123");
        Cliente cliente = new Cliente("Juan", "Perez", "123456789", "Calle 123");
        Factura factura = new Factura();
        Proveedor proveedor = new Proveedor();
        Medidor medidor = new Medidor();
        DispositivoElectrico dispositivoElectrico = new DispositivoElectrico();
        persona.setNombre("Juan");
        persona.setApellido("Perez");
        persona.setID("123456789");
        persona.setDireccion("Calle 123");

    }
}