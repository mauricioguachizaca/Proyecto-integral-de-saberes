import java.util.ArrayList;

public class Proveedor {
    private Double tarifa;

    public Double getTarifa() {
        return tarifa;
    }

    ArrayList<Factura> facturaList;
    ArrayList<Medidor> medidorList;
}
