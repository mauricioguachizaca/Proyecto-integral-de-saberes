public class DispositivoElectrico {
    private String nombreDispositivo;
    private Double potenciaConsumida;
    private Double  tiempoUso;

    public Double calcularConsumo(){
        return (double) 0;
    }
    Medidor medidor;
}
