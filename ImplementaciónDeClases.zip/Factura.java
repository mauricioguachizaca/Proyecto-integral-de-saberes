import java.util.ArrayList;

public class Factura {
    private String numeroFactura;
    private String fechaEmision;
    private Double IVA;
    private Double total;

    public double pagar(){
        return 0;
    }

    Cliente cliente;
    Proveedor proveedor;

    ArrayList<Medidor> medidorList;

}
