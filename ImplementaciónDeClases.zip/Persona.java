public class Persona {
    private String nombre;
    private String apellido;
    private String direccion;
    private String ID;

    public Persona(String nombre, String apellido, String ID, String direccion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.ID = ID;
        this.direccion = direccion;
    }

    public void setNombre(String juan) {
    }

    public void setApellido(String perez) {
    }

    public void setID(String number) {
    }

    public void setDireccion(String s) {
    }
}
