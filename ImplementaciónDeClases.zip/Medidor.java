import java.util.ArrayList;

public class Medidor {
    private String numeroMedidor;
    private Double registroConsumo;

    public Double calcularConsumoTotal(){
        return (double) 0;
    }

    Proveedor proveedor;

    ArrayList<DispositivoElectrico> dispositivoElectricoList;
}
